import { useEffect, useMemo, useState } from "react";
import { Utensils, Users, CalendarDays, ShieldCheck, ChefHat, Plus, Minus, Download, CheckCircle2, Star, ArrowRight, Leaf, Sparkles } from "lucide-react";

const API = "http://localhost:5000/api";
const money = n => new Intl.NumberFormat("en-IN", { style:"currency", currency:"INR", maximumFractionDigits:0 }).format(n || 0);

export default function App() {
  const [vendors,setVendors] = useState([]);
  const [menu,setMenu] = useState([]);
  const [guests,setGuests] = useState(150);
  const [eventType,setEventType] = useState("College Fest");
  const [diet,setDiet] = useState("Veg");
  const [vendorId,setVendorId] = useState("royal-feast");
  const [selected,setSelected] = useState(["paneer-tikka","crispy-corn","veg-biryani","paneer-butter","naan","gulab-jamun","ice-cream"]);
  const [quote,setQuote] = useState(null);
  const [error,setError] = useState("");
  const [tab,setTab] = useState("builder");
  const [tasting,setTasting] = useState({name:"",email:"",vendorId:"royal-feast",date:"",venue:""});
  const [notice,setNotice] = useState("");
  const [loading,setLoading] = useState(true);

  useEffect(() => {
    Promise.all([fetch(`${API}/vendors`).then(r=>r.json()),fetch(`${API}/menu`).then(r=>r.json())])
      .then(([v,m])=>{setVendors(v);setMenu(m);})
      .catch(()=>setError("Could not connect to the server. Start the backend using npm run dev in the server folder."))
      .finally(()=>setLoading(false));
  }, []);

  const selectedVendor = vendors.find(v=>v.id===vendorId) || vendors[0];
  const filteredMenu = useMemo(()=>menu.filter(i => i.course==="Live Counters" || diet==="Non-Veg" || i.diet!=="Non-Veg"),[menu,diet]);

  async function getQuote(forVendor=vendorId) {
    setError(""); setNotice("");
    try {
      const res=await fetch(`${API}/quote`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({guests,selectedItems:selected,vendorId:forVendor})});
      const data=await res.json(); if(!res.ok) throw new Error(data.error);
      setQuote(data); return data;
    } catch(e) { setError(e.message); setQuote(null); return null; }
  }
  useEffect(()=>{ if(menu.length && selected.length) getQuote(); },[guests,selected,vendorId,menu.length]);

  function toggle(id) { setSelected(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]); }
  const courses=["Starters","Mains","Breads","Desserts","Live Counters"];
  async function submitTasting(e) {
    e.preventDefault(); setNotice(""); setError("");
    try {
      const res=await fetch(`${API}/tastings`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(tasting)});
      const data=await res.json(); if(!res.ok) throw new Error(data.error);
      setNotice(`${data.message} Reference: ${data.request.id}`);
      setTasting({name:"",email:"",vendorId,date:"",venue:""});
    } catch(e){setError(e.message);}
  }
  const compareVendors=vendors.filter(v=>v.minGuests<=guests).slice(0,3);

  return <div className="app-shell">
    <header className="topbar"><a className="brand" href="#"><span className="brand-icon"><Utensils size={21}/></span><span>feast<span className="brand-accent">flow</span><small>EVENTEATS EXCHANGE</small></span></a>
      <nav><button className={tab==="builder"?"nav-active":""} onClick={()=>setTab("builder")}>Build a quote</button><button className={tab==="vendors"?"nav-active":""} onClick={()=>setTab("vendors")}>Find caterers</button><button className={tab==="tasting"?"nav-active":""} onClick={()=>setTab("tasting")}>Tasting request</button></nav>
      <span className="trust"><ShieldCheck size={16}/> Transparent pricing</span>
    </header>
    <main>
      <section className="hero"><div><div className="eyebrow"><Sparkles size={14}/> GOOD FOOD. CLEAR PRICES.</div><h1>Make your event<br/><em>taste unforgettable.</em></h1><p>Build a menu everyone will love, see the real numbers, and find a caterer you can count on.</p><div className="hero-points"><span><CheckCircle2/> No hidden costs</span><span><CheckCircle2/> Compare in minutes</span></div></div><div className="hero-art"><div className="art-circle"><Utensils size={76}/></div><div className="float-card"><span>YOUR EVENT, YOUR MENU</span><strong>Made to celebrate.</strong><small>From first bite to final bill.</small></div></div></section>

      <div className="step-row"><div className="step active"><b>01</b><span>Plan your event</span></div><ArrowRight/><div className="step"><b>02</b><span>Build your menu</span></div><ArrowRight/><div className="step"><b>03</b><span>Compare & book</span></div></div>

      {error && <div className="alert error">{error}</div>}{notice && <div className="alert success"><CheckCircle2 size={18}/>{notice}</div>}
      {loading ? <div className="loading">Preparing your FeastFlow kitchen…</div> : <>
      {tab==="builder" && <div className="workspace">
        <section className="main-panel">
          <div className="section-heading"><div><div className="eyebrow">LET'S GET THE DETAILS</div><h2>Tell us about your event</h2><p>A few details help us suggest the right menu and budget.</p></div><span className="step-tag">STEP 01</span></div>
          <div className="form-grid">
            <label>Event type<select value={eventType} onChange={e=>setEventType(e.target.value)}>{["College Fest","Birthday","Corporate","Wedding"].map(x=><option>{x}</option>)}</select></label>
            <label>Dietary preference<select value={diet} onChange={e=>setDiet(e.target.value)}>{["Veg","Non-Veg","Jain"].map(x=><option>{x}</option>)}</select></label>
          </div>
          <div className="guest-box"><div><label className="field-title"><Users size={17}/> How many guests are you expecting?</label><p>We'll use this to calculate your volume discount.</p></div><div className="guest-number">{guests}<small>guests</small></div></div>
          <input className="range" type="range" min="50" max="500" step="10" value={guests} onChange={e=>setGuests(Number(e.target.value))}/><div className="range-labels"><span>50 guests</span><span>500 guests</span></div>
          <div className="section-heading menu-heading"><div><div className="eyebrow">STEP 02 · MAKE IT YOURS</div><h2>Build your menu</h2><p>Pick the dishes that will make your event special.</p></div><span className="selected-count">{selected.length} selected</span></div>
          {courses.map(course=><div className="course-block" key={course}><div className="course-title"><h3>{course}</h3><span>{menu.filter(i=>i.course===course).length} options</span></div><div className="dish-grid">{filteredMenu.filter(i=>i.course===course).map(item=><button key={item.id} className={`dish ${selected.includes(item.id)?"dish-selected":""}`} onClick={()=>toggle(item.id)}><span className="dish-check">{selected.includes(item.id)?"✓":"+"}</span><span className="dish-name">{item.name}</span><span className="dish-price">{item.fixed?money(item.price)+" flat":money(item.price)+"/plate"}</span></button>)}</div></div>)}
          <div className="buffer-note"><Leaf size={18}/><span><b>A little extra goes a long way.</b> We recommend planning food for {quote?.bufferGuests || Math.ceil(guests*1.1)} people (10% buffer) to help avoid running short.</span></div>
        </section>

        <aside className="quote-panel"><div className="quote-top"><span className="quote-label">YOUR LIVE ESTIMATE</span><span className="live-dot">LIVE</span><h2>{money(quote?.perPlate)}<small>/ person</small></h2><p>Estimated total for {guests} guests</p><div className="total-band"><span>Estimated event total</span><strong>{money(quote?.total)}</strong></div></div>
          <div className="quote-details"><h3>Quote breakdown</h3><Line label="Food cost" value={money(quote?.rawFoodCost)}/><Line label={`Volume discount (${quote?.discountPercent||0}%)`} value={`− ${money(quote?.discount)}`} green/><Line label="Live counter add-ons" value={money(quote?.counterCost)}/><Line label="Service fee (5%)" value={money(quote?.serviceFee)}/><Line label="Estimated tax (5%)" value={money(quote?.tax)}/><div className="quote-divider"/><Line label="Total estimate" value={money(quote?.total)} bold/></div>
          <label className="vendor-select">Get quote from<select value={vendorId} onChange={e=>setVendorId(e.target.value)}>{vendors.filter(v=>v.minGuests<=guests).map(v=><option value={v.id}>{v.name}</option>)}</select></label>
          <button className="primary-btn full" onClick={()=>setTab("vendors")}>Compare caterers <ArrowRight size={17}/></button>
          <button className="secondary-btn full" onClick={()=>window.print()}><Download size={16}/> Download / Print quote</button>
          <p className="fine-print">A planning estimate, not a final vendor contract. Prices are sample data.</p>
        </aside>
      </div>}

      {tab==="vendors" && <section className="content-panel"><div className="section-heading"><div><div className="eyebrow">STEP 03 · CHOOSE WITH CONFIDENCE</div><h2>Compare your caterers</h2><p>Clear prices and useful details, all in one place.</p></div><span className="step-tag">VERIFIED LISTINGS</span></div>
        <div className="vendor-grid">{compareVendors.map(v=><article className={`vendor-card ${vendorId===v.id?"vendor-chosen":""}`} key={v.id}><div className="vendor-icon"><ChefHat size={25}/></div><div className="verified"><ShieldCheck size={14}/> Verified profile</div><h3>{v.name}</h3><p>{v.description}</p><div className="rating"><Star size={16} fill="currentColor"/><b>{v.rating}</b><span>({v.reviews} reviews)</span></div><div className="vendor-meta"><span>Minimum guests</span><b>{v.minGuests}+</b></div><div className="vendor-meta"><span>Indicative starting rate</span><b>{money(v.baseRate)}/plate</b></div><div className="vendor-meta"><span>Specialties</span><b>{v.specialties.join(" · ")}</b></div><button className={vendorId===v.id?"selected-btn":"secondary-btn full"} onClick={()=>{setVendorId(v.id);setTab("builder");}}> {vendorId===v.id?"Currently selected":"Select caterer"} </button></article>)}</div>
        <div className="compare-table-wrap"><h3>At-a-glance comparison</h3><table><thead><tr><th>Caterer</th><th>Rating</th><th>Minimum guests</th><th>Starting rate</th><th>Action</th></tr></thead><tbody>{compareVendors.map(v=><tr key={v.id}><td>{v.name}</td><td>⭐ {v.rating}</td><td>{v.minGuests}</td><td>{money(v.baseRate)}/plate</td><td><button className="text-btn" onClick={()=>{setVendorId(v.id);setTab("builder");}}>Build quote</button></td></tr>)}</tbody></table></div>
      </section>}

      {tab==="tasting" && <section className="content-panel tasting-panel"><div className="section-heading"><div><div className="eyebrow">TRY BEFORE YOU DECIDE</div><h2>Book a tasting session</h2><p>Good food deserves a taste test. Send a request to your preferred caterer.</p></div><span className="step-tag">NO COMMITMENT</span></div><form className="tasting-form" onSubmit={submitTasting}><label>Your name<input required value={tasting.name} onChange={e=>setTasting({...tasting,name:e.target.value})} placeholder="e.g. Ananya Rao"/></label><label>Email address<input required type="email" value={tasting.email} onChange={e=>setTasting({...tasting,email:e.target.value})} placeholder="you@example.com"/></label><label>Preferred caterer<select value={tasting.vendorId} onChange={e=>setTasting({...tasting,vendorId:e.target.value})}>{vendors.map(v=><option value={v.id}>{v.name}</option>)}</select></label><label>Preferred date<input required type="date" min={new Date().toISOString().slice(0,10)} value={tasting.date} onChange={e=>setTasting({...tasting,date:e.target.value})}/></label><label className="wide">Venue / area<input required value={tasting.venue} onChange={e=>setTasting({...tasting,venue:e.target.value})} placeholder="College campus, Hyderabad"/></label><button className="primary-btn" type="submit">Send tasting request <ArrowRight size={17}/></button></form></section>}
      </>}
      <section className="milestone"><div><div className="eyebrow">PLAN PAYMENTS WITH CLARITY</div><h3>A simple 3-step payment plan</h3><p>Example only — final terms should be agreed with the caterer.</p></div><div className="milestone-items"><div><b>20%</b><span>Advance</span><small>{money((quote?.total||0)*.2)}</small></div><div><b>50%</b><span>Event day</span><small>{money((quote?.total||0)*.5)}</small></div><div><b>30%</b><span>After event</span><small>{money((quote?.total||0)*.3)}</small></div></div></section>
    </main>
    <footer><a className="brand" href="#"><span className="brand-icon"><Utensils size={18}/></span><span>feast<span className="brand-accent">flow</span><small>EVENTEATS EXCHANGE</small></span></a><span>Thoughtful planning. Happier gatherings.</span><span>© 2026 FeastFlow · Hackathon demo</span></footer>
  </div>;
}
function Line({label,value,green,bold}) { return <div className={`line ${green?"green":""} ${bold?"bold":""}`}><span>{label}</span><b>{value}</b></div>; }
