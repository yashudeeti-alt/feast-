# FeastFlow – EventEats Exchange

A human-friendly catering marketplace mini project for college hackathons. Organizers can build a menu, estimate an event budget, compare caterers, request a tasting session, and print a quotation.

## Features
- Event type and dietary preference selection (Veg, Non-Veg, Jain)
- Guest count calculator (50–500) with volume discounts
- Course-wise menu builder and live food counter add-ons
- Itemized quote: food, live counters, service fee, tax and total
- Vendor directory and side-by-side comparison
- Tasting request form (stored in server memory for this demo)
- 10% suggested food buffer and 20/50/30 payment milestone simulator
- Print / Save as PDF using the browser print dialog
- Responsive layout and basic API validation/security middleware

## Requirements
- Node.js 18 or newer
- npm

## Run locally

Open two terminals.

### 1. Start the backend
```bash
cd server
npm install
npm run dev
```
API runs at http://localhost:5000

### 2. Start the frontend
```bash
cd client
npm install
npm run dev
```
Open the URL printed by Vite (usually http://localhost:5173).

## Demo flow
1. Choose College Fest or Birthday.
2. Set guests to 150.
3. Choose dishes from each course.
4. Review the live estimate.
5. Compare the suggested caterers.
6. Request a tasting session.
7. Click “Download / Print Quote” and choose “Save as PDF”.

## Pricing assumptions
- 50–99 guests: no volume discount
- 100–199 guests: 5% discount
- 200+ guests: 10% discount
- Service fee: 5% of discounted food + counter cost
- Tax: 5% of subtotal after service fee

These are sample demo assumptions, not real vendor offers. All vendor names, ratings and prices are fictional sample data. Update them before a real deployment.

## Project structure
```text
FeastFlow/
├── client/                 # React + Vite frontend
│   └── src/
├── server/                 # Express REST API
│   ├── data/
│   ├── routes/
│   └── services/
└── README.md
```

## API endpoints
- `GET /api/health` – health check
- `GET /api/vendors` – list sample caterers
- `GET /api/menu` – list sample menu items
- `POST /api/quote` – calculate a quote
- `POST /api/tastings` – validate and record a tasting request

## Notes
The tasting requests are held in server memory and reset when the server restarts. For production, use a database, authentication, real vendor verification, server-side payment integration and persistent booking records.
