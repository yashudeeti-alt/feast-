import { menuItems, vendors } from "../data/catalog.js";

const round = (value) => Math.round(value * 100) / 100;

export function calculateQuote({ guests, selectedItems = [], vendorId, servicePercent = 5, taxPercent = 5 }) {
  const count = Number(guests);
  if (!Number.isInteger(count) || count < 50 || count > 500) {
    throw new Error("Guest count must be a whole number between 50 and 500.");
  }
  if (!Array.isArray(selectedItems) || selectedItems.length === 0) {
    throw new Error("Please select at least one menu item.");
  }
  const vendor = vendors.find(v => v.id === vendorId) || vendors[0];
  if (count < vendor.minGuests) {
    throw new Error(`${vendor.name} requires at least ${vendor.minGuests} guests.`);
  }
  const items = selectedItems.map(id => menuItems.find(item => item.id === id)).filter(Boolean);
  if (items.length !== selectedItems.length) throw new Error("One or more selected menu items are invalid.");

  const foodPerPlate = items.filter(i => !i.fixed).reduce((sum, item) => sum + item.price, 0);
  const counterCost = items.filter(i => i.fixed).reduce((sum, item) => sum + item.price, 0);
  const discountPercent = count >= 200 ? 10 : count >= 100 ? 5 : 0;
  const rawFoodCost = foodPerPlate * count;
  const discount = rawFoodCost * discountPercent / 100;
  const discountedFood = rawFoodCost - discount;
  const serviceFee = (discountedFood + counterCost) * servicePercent / 100;
  const tax = (discountedFood + counterCost + serviceFee) * taxPercent / 100;
  const total = discountedFood + counterCost + serviceFee + tax;
  return {
    vendor, guests: count, items, foodPerPlate: round(foodPerPlate),
    rawFoodCost: round(rawFoodCost), discountPercent, discount: round(discount),
    counterCost: round(counterCost), serviceFee: round(serviceFee), tax: round(tax),
    total: round(total), perPlate: round(total / count),
    bufferGuests: Math.ceil(count * 1.1),
    milestones: { advance: round(total * .2), eventDay: round(total * .5), settlement: round(total * .3) }
  };
}
