export const vendors = [
  { id: "royal-feast", name: "Royal Feast Caterers", rating: 4.8, reviews: 126, minGuests: 50, baseRate: 450, specialties: ["Traditional", "Wedding", "College events"], verified: true, description: "Classic Indian menus with attentive event service." },
  { id: "spice-symphony", name: "Spice Symphony", rating: 4.5, reviews: 98, minGuests: 25, baseRate: 420, specialties: ["Regional", "Vegetarian", "Corporate"], verified: true, description: "Regional favourites and flexible menu combinations." },
  { id: "urban-platter", name: "Urban Platter Events", rating: 4.6, reviews: 74, minGuests: 75, baseRate: 520, specialties: ["Continental", "Live counters"], verified: true, description: "Modern menus, snacks and interactive food stations." },
  { id: "green-leaf", name: "Green Leaf Kitchens", rating: 4.7, reviews: 83, minGuests: 30, baseRate: 360, specialties: ["Pure vegetarian", "Jain"], verified: true, description: "Vegetarian and Jain-friendly menu options." },
  { id: "celebrate-bites", name: "Celebrate Bites", rating: 4.4, reviews: 61, minGuests: 100, baseRate: 490, specialties: ["Birthday", "College fest"], verified: true, description: "Crowd-pleasing menus for lively celebrations." }
];

export const menuItems = [
  { id:"paneer-tikka", name:"Paneer Tikka", course:"Starters", diet:"Veg", price:75 },
  { id:"veg-manchurian", name:"Veg Manchurian", course:"Starters", diet:"Veg", price:60 },
  { id:"crispy-corn", name:"Crispy Corn", course:"Starters", diet:"Veg", price:55 },
  { id:"chicken-65", name:"Chicken 65", course:"Starters", diet:"Non-Veg", price:95 },
  { id:"fish-fry", name:"Fish Fry", course:"Starters", diet:"Non-Veg", price:110 },
  { id:"hummus-pita", name:"Hummus & Pita", course:"Starters", diet:"Jain", price:70 },
  { id:"veg-biryani", name:"Veg Dum Biryani", course:"Mains", diet:"Veg", price:120 },
  { id:"paneer-butter", name:"Paneer Butter Masala", course:"Mains", diet:"Veg", price:105 },
  { id:"dal-tadka", name:"Dal Tadka", course:"Mains", diet:"Jain", price:75 },
  { id:"chicken-biryani", name:"Chicken Biryani", course:"Mains", diet:"Non-Veg", price:145 },
  { id:"butter-chicken", name:"Butter Chicken", course:"Mains", diet:"Non-Veg", price:150 },
  { id:"mixed-veg", name:"Seasonal Mixed Vegetables", course:"Mains", diet:"Jain", price:85 },
  { id:"naan", name:"Butter Naan", course:"Breads", diet:"Veg", price:25 },
  { id:"roti", name:"Tandoori Roti", course:"Breads", diet:"Jain", price:18 },
  { id:"paratha", name:"Lachha Paratha", course:"Breads", diet:"Veg", price:30 },
  { id:"gulab-jamun", name:"Gulab Jamun", course:"Desserts", diet:"Veg", price:40 },
  { id:"ice-cream", name:"Vanilla Ice Cream", course:"Desserts", diet:"Veg", price:45 },
  { id:"fruit-cup", name:"Fresh Fruit Cup", course:"Desserts", diet:"Jain", price:50 },
  { id:"brownie", name:"Chocolate Brownie", course:"Desserts", diet:"Veg", price:65 },
  { id:"kheer", name:"Rice Kheer", course:"Desserts", diet:"Veg", price:45 },
  { id:"chaat", name:"Live Chaat Counter", course:"Live Counters", diet:"Veg", price:3500, fixed:true },
  { id:"pasta", name:"Live Pasta Station", course:"Live Counters", diet:"Veg", price:5000, fixed:true },
  { id:"teppanyaki", name:"Ice Cream Teppanyaki", course:"Live Counters", diet:"Veg", price:6500, fixed:true }
];
