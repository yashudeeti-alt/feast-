import { Router } from "express";
import { vendors, menuItems } from "../data/catalog.js";
import { calculateQuote } from "../services/quoteService.js";

const router = Router();
const tastingRequests = [];

router.get("/health", (_req, res) => res.json({ status: "ok", app: "FeastFlow API" }));
router.get("/vendors", (_req, res) => res.json(vendors));
router.get("/menu", (_req, res) => res.json(menuItems));

router.post("/quote", (req, res) => {
  try {
    const quote = calculateQuote(req.body);
    res.json(quote);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.post("/tastings", (req, res) => {
  const { name, email, vendorId, date, venue } = req.body || {};
  if (![name, email, vendorId, date, venue].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please complete every tasting request field." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: "Please enter a valid email address." });
  }
  if (!vendors.some(v => v.id === vendorId)) {
    return res.status(400).json({ error: "Please select a valid caterer." });
  }
  const request = { id: `TASTE-${Date.now()}`, name: name.trim(), email: email.trim(), vendorId, date, venue: venue.trim(), createdAt: new Date().toISOString() };
  tastingRequests.push(request);
  res.status(201).json({ message: "Your tasting request has been received.", request });
});

export default router;
